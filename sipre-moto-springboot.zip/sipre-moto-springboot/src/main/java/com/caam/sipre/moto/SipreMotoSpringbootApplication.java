package com.caam.sipre.moto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SipreMotoSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SipreMotoSpringbootApplication.class, args);
	}

}
