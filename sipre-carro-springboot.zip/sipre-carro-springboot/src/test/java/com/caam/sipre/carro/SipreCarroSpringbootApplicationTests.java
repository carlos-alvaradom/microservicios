package com.caam.sipre.carro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SipreCarroSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
