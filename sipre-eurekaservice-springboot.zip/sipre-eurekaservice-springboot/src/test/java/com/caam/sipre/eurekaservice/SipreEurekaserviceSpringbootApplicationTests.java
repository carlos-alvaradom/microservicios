package com.caam.sipre.eurekaservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SipreEurekaserviceSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
