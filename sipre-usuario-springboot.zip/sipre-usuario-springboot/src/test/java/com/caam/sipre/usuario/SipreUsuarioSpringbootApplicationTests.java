package com.caam.sipre.usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SipreUsuarioSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
