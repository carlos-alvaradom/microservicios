package com.caam.sipre.usuario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SipreUsuarioSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SipreUsuarioSpringbootApplication.class, args);
	}

}
